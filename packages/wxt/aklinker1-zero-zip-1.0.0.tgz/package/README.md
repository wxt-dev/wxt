# `@aklinker1/zero-zip`

Zero dependency, tiny util for creating ZIP files.

```sh
bun add @aklinker1/zero-zip
```

## Supported Runtimes

- ✅ Node, Deno, Bun - any runtime with `node:zlib`
- ❌ Browser

## Features

-
